const https = require("https");

const SEASONAL_CONTEXT = {
  hlc: [
    { months: [1],        note: "Midterm season. Students stressed about grades. Push tutoring urgency." },
    { months: [2],        note: "Regents prep begins. SAT coming in March. Good time for test prep push." },
    { months: [3],        note: "SAT test date (early March). Spring break tutoring intensives. Regents cramming." },
    { months: [4],        note: "April SAT. Spring Regents approaching. SHSAT score releases. IEP annual review season." },
    { months: [5],        note: "AP exams. Regents prep in full swing. End of year grades matter." },
    { months: [6],        note: "Regents exams (mid-June). School year ends. Summer program enrollment critical — fight the summer slide." },
    { months: [7, 8],     note: "Summer tutoring season. Summer slide prevention. Fall readiness. SAT August test date." },
    { months: [9],        note: "Back to school. SHSAT registration opens (Sep-Oct for 8th graders). October SAT coming." },
    { months: [10],       note: "SHSAT exam (late October). PSAT. SAT October date. Fall tutoring momentum." },
    { months: [11],       note: "November SAT. Fall Regents approaching. Push urgency before holiday break." },
    { months: [12],       note: "Final exams before winter break. January Regents prep begins. Holiday tutoring packages." },
  ],
  dj: [
    { months: [1],        note: "New Year new look. Winter color trends. Dry winter hair treatments." },
    { months: [2],        note: "Valentine's Day. Special occasion blowouts. Galentine's group bookings." },
    { months: [3],        note: "Spring refresh. Color correction after winter. Early prom bookings." },
    { months: [4],        note: "Prom season ramp-up. Easter looks. Spring wedding hair trials." },
    { months: [5],        note: "PEAK GRADUATION AND PROM SEASON. Mother's Day — gift cards and pamper packages. Bridal bookings." },
    { months: [6],        note: "Graduation parties. Wedding season. Summer color — balayage, highlights, beachy looks." },
    { months: [7, 8],     note: "Summer maintenance. UV protection treatments. Back to school cuts approaching." },
    { months: [9],        note: "Back to school fresh cuts. Fall color transition — warmer tones, brunettes." },
    { months: [10],       note: "Fall color season peak. Halloween event looks." },
    { months: [11],       note: "Holiday glam prep begins. Thanksgiving family photos. Gift card push." },
    { months: [12],       note: "Holiday party looks. NYE glam. Gift cards — biggest gift card month." },
  ],
  sn: [
    { months: [1],        note: "New Year celebrations. Cold weather comfort food. Push group dining deals." },
    { months: [2],        note: "Valentine's Day romantic dinner specials. Cozy winter dining." },
    { months: [3],        note: "Nowruz (Central Asian New Year, March 20-21) — huge cultural moment. Push traditional dishes." },
    { months: [4],        note: "Ramadan/Eid al-Fitr (date varies). Spring catering. Easter family dinners." },
    { months: [5],        note: "Mother's Day family dinner push. Graduation dinner reservations." },
    { months: [6],        note: "Graduation dinners. Father's Day. Summer group events." },
    { months: [7, 8],     note: "Summer dining. Outdoor event season. Catering for summer parties." },
    { months: [9],        note: "Back to school family dinners. Fall menu. Labor Day group gatherings." },
    { months: [10],       note: "Fall comfort food. Halloween events. Private event bookings for holidays." },
    { months: [11],       note: "Thanksgiving alternative angle. Friendsgiving group bookings. Early holiday party reservations." },
    { months: [12],       note: "Holiday parties. NYE dinner — biggest night of the year. Corporate catering. Gift cards." },
  ]
};

function getSeasonalNote(biz) {
  const now = new Date();
  const month = now.getMonth() + 1;
  const year = now.getFullYear();
  const monthName = now.toLocaleString("en-US", { month: "long" });
  const entries = SEASONAL_CONTEXT[biz] || [];
  const current = entries.find(e => e.months.includes(month));
  const nextMonth = month === 12 ? 1 : month + 1;
  const upcoming = entries.find(e => e.months.includes(nextMonth));
  const nextMonthName = new Date(year, month, 1).toLocaleString("en-US", { month: "long" });
  let note = `Today is ${monthName} ${now.getDate()}, ${year}.\n`;
  if (current) note += `Current: ${current.note}\n`;
  if (upcoming) note += `Coming up (${nextMonthName}): ${upcoming.note}`;
  return note;
}

const BIZ = {
  hlc: {
    name: "Huntington Learning Center of Bay Ridge",
    context: `Huntington Learning Center of Bay Ridge, an independently owned franchise at 514 86th Street, Bay Ridge, Brooklyn, NY 11209. Services: K-12 tutoring, small group instruction, SAT/ACT prep, SHSAT prep, IEP support, and IHO compensatory education. Brand: green #3AAA35 and purple. Audience: Brooklyn parents.`
  },
  dj: {
    name: "David James Salon & Day Spa",
    context: `David James Salon & Day Spa, 6171 Strickland Ave, Brooklyn, NY. Phone: 718-444-4040. Website: DavidJames.net. Services: hair coloring, cuts, styling, facials, spa treatments. Upscale but approachable Brooklyn salon.`
  },
  sn: {
    name: "Samarkand Nights Restaurant",
    context: `Samarkand Nights, a Central Asian/Uzbek restaurant at 6001 Strickland Ave, Brooklyn, NY. Phone: 718-650-7600. Cuisine: plov, shashlik, lagman, samsa, and more. Authentic, cultural, great for family dinners and events.`
  }
};

const CTA_MAP = {
  "call-us":     { hlc: "Call us at 718-491-0900.", dj: "Call us at 718-444-4040.", sn: "Call us at 718-650-7600 to reserve your table." },
  "book-now":    { hlc: "Book a free assessment at 718-491-0900.", dj: "Book your appointment at DavidJames.net.", sn: "Reserve your table now — call 718-650-7600." },
  "dm-us":       { hlc: "DM us to get started.", dj: "DM us to book your appointment.", sn: "DM us to make a reservation." },
  "link-in-bio": { hlc: "Link in bio to learn more.", dj: "Link in bio to book.", sn: "Link in bio for reservations." },
  "visit-us":    { hlc: "Visit us at 514 86th Street, Bay Ridge.", dj: "Visit us at 6171 Strickland Ave, Brooklyn.", sn: "Visit us at 6001 Strickland Ave, Brooklyn." },
};

function claudeRequest(payload) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req = https.request({
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body),
        "anthropic-version": "2023-06-01",
        "x-api-key": process.env.ANTHROPIC_API_KEY
      }
    }, res => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error("Bad JSON")); }
      });
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };

  try {
    const { biz, brief, imageBase64, seasonalHook, tone, cta, promo } = JSON.parse(event.body);
    const bizData = BIZ[biz];
    if (!bizData) return { statusCode: 400, body: JSON.stringify({ error: "Invalid biz" }) };

    const seasonal = getSeasonalNote(biz);
    const ctaText = cta && cta !== "none" ? CTA_MAP[cta]?.[biz] || "" : "";
    const toneGuide = {
      professional: "Professional and authoritative. Confident but warm.",
      casual: "Casual, friendly, conversational. Like a neighbor talking to you.",
      hype: "High energy, punchy, exciting. Short sentences. Bold claims. Urgency."
    }[tone] || "Natural and warm.";

    const systemPrompt = `You are a social media marketing expert for ${bizData.name}.

Business context: ${bizData.context}

Seasonal context: ${seasonal}
${seasonalHook ? `Seasonal hook: ${seasonalHook}` : ""}
${promo ? `Current promo/offer to mention: ${promo}` : ""}

Tone: ${toneGuide}
${ctaText ? `Call to action to include: ${ctaText}` : ""}

Rules:
- No em dashes. Use periods or commas instead.
- No AI filler phrases ("Elevate your...", "Transform your...", "Unlock...").
- Brooklyn local voice where appropriate.
- Weave in seasonal context naturally.
- Each platform caption must feel native to that platform.

Return ONLY valid JSON in this exact structure, no preamble, no markdown:
{
  "instagram": {
    "caption": "Full Instagram caption (150-300 chars, storytelling, emoji okay)",
    "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]
  },
  "tiktok": {
    "caption": "TikTok caption (under 150 chars, punchy, hook-first, trend-aware)",
    "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]
  },
  "facebook": {
    "caption": "Facebook caption (200-400 chars, conversational, community feel, can be longer)",
    "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]
  }
}`;

    const userContent = [];
    if (imageBase64) {
      userContent.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: imageBase64 } });
      userContent.push({ type: "text", text: `Brief: ${brief || "Write captions for this image."}` });
    } else {
      userContent.push({ type: "text", text: brief });
    }

    const result = await claudeRequest({
      model: "claude-sonnet-4-6",
      max_tokens: 1200,
      system: systemPrompt,
      messages: [{ role: "user", content: userContent }]
    });

    const raw = result.content?.[0]?.text?.trim() || "{}";
    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify(parsed)
    };

  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
