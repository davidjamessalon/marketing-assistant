const https = require("https");
const http = require("http");
const crypto = require("crypto");

const CLOUD = process.env.CLOUDINARY_CLOUD_NAME || "deovadc9e";
const API_KEY = process.env.CLOUDINARY_API_KEY || "915888875482254";
const API_SECRET = process.env.CLOUDINARY_API_SECRET || "U8O238vhgToRwq2C3PhfvkQHvKo";

// Logo public IDs — update these after uploading to Cloudinary Media Library
const LOGOS = {
  hlc: "logos/hlc",
  dj:  "logos/dj",
  sn:  "logos/sn"
};

// Brand color overlays per business
const BRAND = {
  hlc: { color: "3AAA35", textColor: "ffffff" },
  dj:  { color: "1a1a1a", textColor: "c9a96e" },
  sn:  { color: "1a0a00", textColor: "d4a017" }
};

function sign(params, secret) {
  const str = Object.keys(params).sort().map(k => `${k}=${params[k]}`).join("&") + secret;
  return crypto.createHash("sha1").update(str).digest("hex");
}

function postMultipart(url, fields, fileBuffer, filename) {
  return new Promise((resolve, reject) => {
    const boundary = "----FormBoundary" + Math.random().toString(36).slice(2);
    const parts = [];

    for (const [key, val] of Object.entries(fields)) {
      parts.push(
        `--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${val}`
      );
    }

    const fileHeader = `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: image/jpeg\r\n\r\n`;
    const bodyStart = Buffer.from(parts.join("\r\n") + "\r\n" + fileHeader);
    const bodyEnd = Buffer.from(`\r\n--${boundary}--\r\n`);
    const body = Buffer.concat([bodyStart, fileBuffer, bodyEnd]);

    const urlObj = new URL(url);
    const req = https.request({
      hostname: urlObj.hostname,
      path: urlObj.pathname,
      method: "POST",
      headers: {
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": body.length
      }
    }, res => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error("Bad JSON: " + data)); }
      });
    });

    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };

  try {
    const body = JSON.parse(event.body);
    const { imageBase64, biz, format = "square" } = body;

    if (!imageBase64 || !biz || !LOGOS[biz]) {
      return { statusCode: 400, body: JSON.stringify({ error: "Missing imageBase64 or biz" }) };
    }

    const logo = LOGOS[biz];
    const brand = BRAND[biz];

    // Step 1: Upload the raw user photo to Cloudinary
    const fileBuffer = Buffer.from(imageBase64, "base64");
    const timestamp = Math.floor(Date.now() / 1000);
    const folder = "posts";

    const uploadParams = { folder, timestamp };
    const signature = sign({ ...uploadParams, api_key: API_KEY }, API_SECRET);

    const uploaded = await postMultipart(
      `https://api.cloudinary.com/v1_1/${CLOUD}/image/upload`,
      { ...uploadParams, api_key: API_KEY, signature },
      fileBuffer,
      "upload.jpg"
    );

    if (!uploaded.public_id) {
      return { statusCode: 500, body: JSON.stringify({ error: "Upload failed", detail: uploaded }) };
    }

    const publicId = uploaded.public_id;

    // Step 2: Build Cloudinary transformation URL
    // Crop to square, auto enhance, add logo overlay top-left, add subtle brand gradient at bottom
    const W = format === "story" ? 1080 : 1080;
    const H = format === "story" ? 1920 : 1080;
    const logoW = format === "story" ? 280 : 240;

    const transforms = [
      `w_${W},h_${H},c_fill,g_auto`,          // crop to size
      `e_auto_brightness`,                      // auto brightness
      `e_vibrance:20`,                          // pop the colors
      // Dark gradient bar at bottom for text room
      `l_gradient:fade:southeast,w_${W},h_${Math.round(H*0.35)},g_south,o_70,co_rgb:000000/fl_layer_apply,g_south`,
      // Logo top-left
      `l_${logo.replace("/", ":")},w_${logoW},g_north_west,x_24,y_24,fl_layer_apply`
    ].join("/");

    const brandedUrl = `https://res.cloudinary.com/${CLOUD}/image/upload/${transforms}/${publicId}`;

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ brandedUrl, publicId })
    };

  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
