const https = require("https");

const ACCESS_KEY = process.env.UNSPLASH_ACCESS_KEY || "UnBy28yhK8U_e2G7e5ntQ0A5LF3whSLjxKeLEol0s4A";

// Auto search term suggestions per business + season
const BIZ_SEARCH_HINTS = {
  hlc: ["students studying", "tutoring classroom", "kids learning", "homework help", "SAT prep students", "back to school", "education Brooklyn"],
  dj:  ["hair salon", "hair color", "blowout hairstyle", "beauty salon", "haircut styling", "balayage highlights", "salon spa"],
  sn:  ["Uzbek food", "Central Asian cuisine", "plov rice dish", "shashlik kebab", "restaurant dining", "Middle Eastern food", "ethnic restaurant Brooklyn"]
};

function fetchUnsplash(query, page = 1) {
  return new Promise((resolve, reject) => {
    const params = new URLSearchParams({ query, per_page: 12, page, orientation: "squarish" });
    const req = https.request({
      hostname: "api.unsplash.com",
      path: `/search/photos?${params}`,
      method: "GET",
      headers: {
        "Authorization": `Client-ID ${ACCESS_KEY}`,
        "Accept-Version": "v1"
      }
    }, res => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error("Bad JSON")); }
      });
    });
    req.on("error", reject);
    req.end();
  });
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };

  try {
    const { query, biz, page = 1 } = JSON.parse(event.body);

    const searchQuery = query || BIZ_SEARCH_HINTS[biz]?.[0] || "business marketing";
    const result = await fetchUnsplash(searchQuery, page);

    const photos = (result.results || []).map(p => ({
      id: p.id,
      thumb: p.urls.small,
      regular: p.urls.regular,
      full: p.urls.full,
      alt: p.alt_description || searchQuery,
      photographer: p.user.name,
      downloadUrl: p.links.download_location
    }));

    // Also return suggested searches for this biz
    const suggestions = BIZ_SEARCH_HINTS[biz] || [];

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ photos, suggestions, total: result.total || 0 })
    };

  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
