const https = require("https");

const BIZ_CONTEXT = {
  hlc: "Huntington Learning Center of Bay Ridge - a K-12 tutoring center in Bay Ridge, Brooklyn. Green and white branding. Educational setting.",
  dj: "David James Salon & Day Spa - an upscale hair salon and spa in Brooklyn. Black and gold branding. Beauty and wellness.",
  sn: "Samarkand Nights - an Uzbek/Central Asian restaurant in Brooklyn. Dark, warm, gold branding. Food and dining."
};

const CONTENT_TYPES = {
  hlc: ["Instagram Caption","Carousel Copy","Reel Script","Facebook Post","Email Blast","Google Ad","SMS Blast","Parent Letter"],
  dj:  ["Instagram Caption","Carousel Copy","Reel Script","Promo Post","Email Blast","Google Ad","SMS Blast"],
  sn:  ["Instagram Caption","Carousel Copy","Reel Script","Promo Post","Email Blast","Google Ad","SMS Blast","Event Promo"]
};

// Key dates and seasonal context per business
const SEASONAL_CONTEXT = {
  hlc: [
    { months: [1],        note: "Midterm season. Students stressed about grades. Push tutoring urgency." },
    { months: [2],        note: "Regents prep begins. SAT coming in March. Good time for test prep push." },
    { months: [3],        note: "SAT test date (early March). Spring break tutoring intensives. Regents cramming." },
    { months: [4],        note: "April SAT. Spring Regents approaching. SHSAT score releases (applicants know results). IEP annual review season." },
    { months: [5],        note: "AP exams. Regents prep in full swing. End of year grades matter. Final push before summer." },
    { months: [6],        note: "Regents exams (mid-June). School year ends. Summer program enrollment critical — fight the summer slide." },
    { months: [7, 8],     note: "Summer tutoring season. Summer slide prevention. Fall readiness programs. Back to school prep. SAT August test date." },
    { months: [9],        note: "Back to school. New school year. SHSAT registration opens (Sep-Oct for 8th graders). October SAT coming up." },
    { months: [10],       note: "SHSAT exam (late October). PSAT. SAT October date. Fall tutoring momentum." },
    { months: [11],       note: "November SAT. Fall Regents approaching. Thanksgiving week — limited sessions, push urgency now." },
    { months: [12],       note: "Final exams before winter break. January Regents prep begins. Holiday gift idea: tutoring packages." },
  ],
  dj: [
    { months: [1],        note: "New Year new look. Winter color trends. Dry winter hair treatments." },
    { months: [2],        note: "Valentine's Day. Special occasion blowouts and color. Galentine's group bookings." },
    { months: [3],        note: "Spring refresh. Color correction after winter. Early prom bookings opening." },
    { months: [4],        note: "Prom season ramp-up. Easter looks. Spring wedding hair trials." },
    { months: [5],        note: "PEAK GRADUATION SEASON. Prom. Mother's Day (huge — gift cards, pamper packages). Bridal party bookings." },
    { months: [6],        note: "Graduation parties. Juneteenth. Wedding season kicks off. Summer color — balayage, highlights, beachy looks." },
    { months: [7, 8],     note: "Summer maintenance. UV protection treatments. Vacation ready looks. Back to school cuts for kids approaching." },
    { months: [9],        note: "Back to school fresh cuts. Fall color transition — warmer tones, brunettes. Labor Day weekend." },
    { months: [10],       note: "Fall color season peak. Halloween event looks. Subtle spooky fun styles." },
    { months: [11],       note: "Holiday glam prep begins. Thanksgiving family photos. Gift card push for holiday gifting." },
    { months: [12],       note: "Holiday party looks. NYE glam. Gift cards — biggest gift card month. End of year pampering." },
  ],
  sn: [
    { months: [1],        note: "New Year celebrations. Cold weather comfort food. January is slow — push deals and group dining." },
    { months: [2],        note: "Valentine's Day — romantic dinner for two. Push reservation specials. Cozy winter dining." },
    { months: [3],        note: "Nowruz (Persian/Central Asian New Year, March 20-21) — HUGE cultural moment. Spring awakening. Push traditional dishes." },
    { months: [4],        note: "Ramadan/Eid al-Fitr (date varies). Spring catering season. Easter family dinners." },
    { months: [5],        note: "Mother's Day — family dinner push. Graduation dinner reservations. Warmer weather outdoor interest." },
    { months: [6],        note: "Graduation dinners. Father's Day. Summer group events. Longer evenings = later dining." },
    { months: [7, 8],     note: "Summer dining. Outdoor event season. Catering for summer parties. Push the unique experience angle." },
    { months: [9],        note: "Back to school family dinners. Fall menu tease. Labor Day group gatherings." },
    { months: [10],       note: "Fall comfort food. Halloween events. Cozy atmosphere push. Private event bookings for holidays." },
    { months: [11],       note: "Thanksgiving alternative — 'skip the same old turkey.' Friendsgiving group bookings. Early holiday party reservations." },
    { months: [12],       note: "Holiday parties. NYE dinner reservations — biggest night of the year. Corporate event catering. Gift cards." },
  ]
};

function getSeasonalNote(biz, date) {
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const year = date.getFullYear();

  const entries = SEASONAL_CONTEXT[biz] || [];
  const current = entries.find(e => e.months.includes(month));
  const nextMonth = month === 12 ? 1 : month + 1;
  const upcoming = entries.find(e => e.months.includes(nextMonth));

  const monthName = date.toLocaleString("en-US", { month: "long" });
  const nextMonthName = new Date(year, month, 1).toLocaleString("en-US", { month: "long" });

  let note = `Today is ${monthName} ${day}, ${year}.\n`;
  if (current) note += `Current seasonal context: ${current.note}\n`;
  if (upcoming) note += `Coming up next month (${nextMonthName}): ${upcoming.note}\n`;
  return note;
}

function claudeRequest(payload) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req = https.request({
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body),
        "anthropic-version": "2023-06-01",
        "x-api-key": process.env.ANTHROPIC_API_KEY
      }
    }, res => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error("Bad JSON: " + data)); }
      });
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };

  try {
    const { imageBase64, currentBiz } = JSON.parse(event.body);
    if (!imageBase64) return { statusCode: 400, body: JSON.stringify({ error: "No image provided" }) };

    const now = new Date();
    const bizList = Object.entries(BIZ_CONTEXT).map(([k, v]) => `- ${k}: ${v}`).join("\n");

    // Build seasonal notes for all three businesses
    const allSeasonalNotes = Object.keys(BIZ_CONTEXT).map(biz => {
      return `${biz} seasonal context:\n${getSeasonalNote(biz, now)}`;
    }).join("\n");

    const systemPrompt = `You are a marketing analyst for three Brooklyn businesses. Analyze the provided photo and return a JSON object.

The businesses:
${bizList}

Content types per business:
- hlc: ${CONTENT_TYPES.hlc.join(", ")}
- dj: ${CONTENT_TYPES.dj.join(", ")}
- sn: ${CONTENT_TYPES.sn.join(", ")}

${allSeasonalNotes}

${currentBiz ? `The user has indicated this is likely for: ${currentBiz}. Use that business unless the image clearly contradicts it.` : "Pick the most likely business based on what you see."}

Instructions:
- Factor in the current date and seasonal context heavily. If it's graduation season, lean into that. If SAT is coming up, mention it. If it's Nowruz, use that.
- The brief and postIdea should feel timely and relevant to what's happening right now or coming up soon.
- Pick the content type that will get the most engagement given the season and what's in the photo.

Return ONLY this JSON, no preamble, no markdown:
{
  "biz": one of "hlc", "dj", or "sn",
  "contentType": best content type for this image and season,
  "brief": "1-2 sentence creative brief that weaves in seasonal context",
  "reasoning": "one short sentence explaining your choices including the seasonal angle",
  "postIdea": "punchy 3-6 word headline idea",
  "seasonalHook": "the specific seasonal moment or upcoming date you are tying this to"
}`;

    const result = await claudeRequest({
      model: "claude-sonnet-4-6",
      max_tokens: 600,
      system: systemPrompt,
      messages: [{
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: "image/jpeg", data: imageBase64 } },
          { type: "text", text: "Analyze this image and return the JSON." }
        ]
      }]
    });

    const raw = result.content?.[0]?.text?.trim() || "{}";
    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    if (!["hlc","dj","sn"].includes(parsed.biz)) parsed.biz = currentBiz || "hlc";
    const validTypes = CONTENT_TYPES[parsed.biz];
    if (!validTypes.includes(parsed.contentType)) parsed.contentType = validTypes[0];

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify(parsed)
    };

  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
